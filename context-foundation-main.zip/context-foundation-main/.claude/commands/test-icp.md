---
description: Test the ICP architect agent with a new company
---

Launch the icp-architect agent to build ICP segments for a company.

Ask me which company I want to analyze, then use the icp-architect agent to:
1. Research the company and market
2. Use AskUserQuestion to validate assumptions about pain segments
3. Create pain-based ICP segments with programmatic signals

Start by asking which company to analyze.
