# Claude Skills

This folder contains copied skills from the official Anthropic skills repository.

Installed:
- `pptx`
- `docx`
- `xlsx`
- `pdf`
- `skill-creator`
- `brand-guidelines`

Upstream reference:
- https://github.com/anthropics/skills/tree/main/skills

