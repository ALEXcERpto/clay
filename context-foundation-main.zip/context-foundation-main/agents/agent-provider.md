# agent-provider.md

Canonical file: `agents/provider.md`

This file exists so you can reference “agent-provider.md” in prompts, but the content lives in `agents/provider.md`.

