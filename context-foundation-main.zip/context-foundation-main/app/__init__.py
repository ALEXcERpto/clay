"""
Minimal webhook + cron runner scaffolding.

Run modules with:
  python -m app.webhook_server
  python -m app.worker
  python -m app.cron_enqueue
  python -m app.railway_service
  python -m app.mapping_cli
"""
