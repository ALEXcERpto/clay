from __future__ import annotations

from .http_server import main


if __name__ == "__main__":
    main()

